// Earn Gaming demo: points are virtual and stored only in this browser.
const POINTS_KEY = "earnGamingPoints";
const PLAYED_KEY = "earnGamingPlayed";

let points = Number(localStorage.getItem(POINTS_KEY)) || 0;
let gamesPlayed = Number(localStorage.getItem(PLAYED_KEY)) || 0;

const questions = [
  { q: "भारत की राजधानी क्या है?", options: ["मुंबई", "नई दिल्ली", "कोलकाता"], answer: "नई दिल्ली" },
  { q: "एक सप्ताह में कितने दिन होते हैं?", options: ["5", "7", "10"], answer: "7" },
  { q: "सूरज किस दिशा से निकलता है?", options: ["पूर्व", "पश्चिम", "उत्तर"], answer: "पूर्व" },
  { q: "पानी का रासायनिक सूत्र क्या है?", options: ["CO2", "H2O", "O2"], answer: "H2O" }
];

let questionIndex = 0;
let quizAnswered = false;
let guessPlayed = false;

const pointsEl = document.getElementById("points");
const totalPointsEl = document.getElementById("totalPoints");
const gamesPlayedEl = document.getElementById("gamesPlayed");

function updateDisplay() {
  pointsEl.textContent = points;
  totalPointsEl.textContent = points;
  gamesPlayedEl.textContent = gamesPlayed;
  localStorage.setItem(POINTS_KEY, String(points));
  localStorage.setItem(PLAYED_KEY, String(gamesPlayed));
}

function awardPoints(amount) {
  points += amount;
  gamesPlayed += 1;
  updateDisplay();
}

function showQuestion() {
  const item = questions[questionIndex];
  document.getElementById("question").textContent = item.q;
  document.getElementById("quizMessage").textContent = "";
  document.getElementById("nextQuestion").hidden = true;
  quizAnswered = false;

  const answers = document.getElementById("answers");
  answers.innerHTML = "";
  item.options.forEach(option => {
    const button = document.createElement("button");
    button.className = "answer";
    button.textContent = option;
    button.addEventListener("click", () => answerQuiz(option, button));
    answers.appendChild(button);
  });
}

function answerQuiz(choice, selectedButton) {
  if (quizAnswered) return;
  quizAnswered = true;

  const correct = questions[questionIndex].answer;
  const buttons = document.querySelectorAll("#answers button");
  buttons.forEach(button => { button.disabled = true; });

  if (choice === correct) {
    awardPoints(10);
    document.getElementById("quizMessage").textContent = "सही जवाब! +10 पॉइंट 🎉";
  } else {
    document.getElementById("quizMessage").textContent = `सही जवाब: ${correct}. अगली बार कोशिश करें!`;
  }
  document.getElementById("nextQuestion").hidden = false;
}

document.getElementById("nextQuestion").addEventListener("click", () => {
  questionIndex = (questionIndex + 1) % questions.length;
  showQuestion();
});

document.getElementById("guessButton").addEventListener("click", () => {
  if (guessPlayed) {
    document.getElementById("guessMessage").textContent = "इस राउंड में आप कोशिश कर चुके हैं। पेज रीफ्रेश करके नया राउंड शुरू करें।";
    return;
  }

  const input = document.getElementById("guessInput");
  const guess = Number(input.value);
  const message = document.getElementById("guessMessage");

  if (!Number.isInteger(guess) || guess < 1 || guess > 5) {
    message.textContent = "कृपया 1 से 5 के बीच पूरा नंबर डालें।";
    return;
  }

  guessPlayed = true;
  const secret = Math.floor(Math.random() * 5) + 1;
  if (guess === secret) {
    awardPoints(5);
    message.textContent = `बिल्कुल सही! नंबर ${secret} था। +5 पॉइंट 🎉`;
  } else {
    gamesPlayed += 1;
    updateDisplay();
    message.textContent = `इस बार सही नंबर ${secret} था। फिर कोशिश करने के लिए पेज रीफ्रेश करें।`;
  }
  document.getElementById("guessButton").disabled = true;
  input.disabled = true;
});

document.getElementById("year").textContent = new Date().getFullYear();
updateDisplay();
showQuestion();
